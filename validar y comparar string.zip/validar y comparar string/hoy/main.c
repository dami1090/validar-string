#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    int aux;
    char nombre[31];
    char apellido[31];

    printf("\nIngrese nombre: ");
    setbuf(stdin,NULL);
    scanf("%[^\n]",nombre);//gets(texto);

    printf("\nIngrese apellido: ");
    setbuf(stdin,NULL);
    scanf("%[^\n]",apellido);//gets(texto);

    strlwr(nombre);
    nombre[0]=toupper(nombre[0]);
    strlwr(apellido);
    apellido[0]=toupper(apellido[0]);
    strcat(nombre," ");
    strcat(nombre,apellido);
    printf("\nNombre y apellido: %s\n",nombre);

    aux=strcmp(nombre,apellido);
    printf("strcmp: %d\n",aux);

    return 0;
}
